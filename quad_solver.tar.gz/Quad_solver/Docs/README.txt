Documents in Quad Solver project for CS4900 Spring 2017 Semester.
