// qsolve_roots.h
// version 1.01

float calc_numerator(Input *inputs);
