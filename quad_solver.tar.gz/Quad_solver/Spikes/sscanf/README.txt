spike created for using fgets with sscanf to save value into a float
