#include "all.h"
int main(int argc, char* argv[]){
	testNAN();	
	testINF();
	return 0;	
}
