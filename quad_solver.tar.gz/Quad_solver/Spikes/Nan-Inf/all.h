#ifndef all_H
#define all_H

#include <stdio.h>
#include <math.h>
#include <float.h>
	
void testNAN(void);
void testINF(void);


#endif
