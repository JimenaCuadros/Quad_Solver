spike created for calculating relative and absolute error
