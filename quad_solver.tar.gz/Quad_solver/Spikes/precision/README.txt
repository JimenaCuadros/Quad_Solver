spike created for precision of floats and doubles
