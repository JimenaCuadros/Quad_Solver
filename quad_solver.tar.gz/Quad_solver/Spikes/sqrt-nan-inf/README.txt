spike created for finding the square root of NAN, INFINITY, -NAN, and -INFINITY
