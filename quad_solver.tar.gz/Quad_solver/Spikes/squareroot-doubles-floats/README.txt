spike created for testing sqrt() and sqrtf() with doubles and floats
