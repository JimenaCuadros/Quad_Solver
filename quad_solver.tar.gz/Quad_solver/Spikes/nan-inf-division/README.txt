spike created for dividing by both infinity and nan
