
float calc_numerator(float a, float b, float c){
	float numerator = 0.0;
	numerator = (b*b)-(4*(a*c));	
	return numerator;
}
