#ifndef STRUCTS_H
#define STRUCTS_H

typedef struct {
	float x1, x2;
	int valid, oneroot;
} Roots;

typedef struct{
	float a,b,c;
}Input;
#endif
