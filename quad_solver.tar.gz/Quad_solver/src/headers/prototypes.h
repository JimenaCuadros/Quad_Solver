#ifndef PROTOTYPES_H
#define	PROTOTYPES_H

float calc_numerator(float a, float b, float c);
Input input_validation(void);
Roots calc_roots(float numerator, Input inputs, Roots roots);
#endif
